# ICD-CODES API Requirements

## Why
The icd-codes api provides a simple for users to add and retrieve icd-codes classifications. The api can be used to create mobile, web and desktop applications.

## User Stories
- As a user, I should be able to create a diagnosis code record.
- As a user, I should be able to edit a diagnosis code record that I created
- As a user, I should be able to delete a diagnosis code that I created
- As a user, I should be able to view all the dignosis code records that I have   permission to view
- As a user, I should be able to view a single dignosis code record by supplying the id
- As a user, I should be able to create multiple diagnosis code records by uploading a CSV file
- As a user, I should receive an email notification after a successful upload

